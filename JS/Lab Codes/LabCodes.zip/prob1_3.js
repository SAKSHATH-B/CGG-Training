

function hello(){
    return `<hr>This text is displayed by <u><i>calling external function</i></u> : <strong>Hello World</strong><hr>`
}   

document.write(hello())