document.write('<code>The actual script is in external script file called "Common.js"</code><br>')


function addNums(a,b){
    return a+b
}