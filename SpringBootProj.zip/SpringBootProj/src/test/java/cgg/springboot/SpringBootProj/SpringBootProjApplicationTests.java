package cgg.springboot.SpringBootProj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
