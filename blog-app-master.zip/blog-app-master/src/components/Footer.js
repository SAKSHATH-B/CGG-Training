import React from 'react'

export const Footer = () => {
    return (
        <div>
            <h1 style={{backgroundColor:'#e2e2e2',
             color:'white'}}>This is footer</h1>
        </div>
    )
}
