import React from 'react'
import { CustomNavbar } from './CustomNavbar'

export const Header = () => {
    return (
        <div>
           <CustomNavbar/>
        </div>
    )
}
