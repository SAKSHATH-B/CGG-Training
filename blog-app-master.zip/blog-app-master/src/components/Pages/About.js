import React from 'react'
import { Base } from '../Base'

export const About = () => {
    return (
        <div>
         <Base>
          <h1>This is about page</h1> 
        </Base> 
        </div>
    )
}
