import React from 'react'
import { Base } from '../../Base'
import { AddPost } from '../../AddPost'

export const Dashboard = () => {
    return (
        
           <AddPost/>
       
    )
}
