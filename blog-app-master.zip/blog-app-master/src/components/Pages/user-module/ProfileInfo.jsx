import React from 'react'

export const ProfileInfo = () => {
    return (
        <div>
            <h1>This is my profile info</h1>
        </div>
    )
}
