import React from 'react'
import {Base} from './Base'
export const Services = () => {
    return (
        <div>
            <Base>
                <h1>this is services page</h1>
            </Base>
        </div>
    )
}
